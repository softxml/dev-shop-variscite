<?php
exit;
define( 'WP_DEBUG', true );
require_once( 'wp-config.php' );

$formdata = array();
$formdata['payment_status'] = 'Completed';
$formdata['order_id'] = 18827;
do_action( 'valid-variscite-paypal-ipn-request-test', $formdata );