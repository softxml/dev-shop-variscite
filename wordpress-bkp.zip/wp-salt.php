<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'MgasFY4CD1YDDRo0b09TM5VzGSSqc6Gm186X0I129vIfbCUnqQtRvnDAH3L2i9Qr');
define('SECURE_AUTH_KEY',  'dV0oDdVAtsMebIFrLxI0nbuMK4TYQt7f84XJQyCTuFRSgyKsQfdHjxzYgXczUWaH');
define('LOGGED_IN_KEY',    'VWPq2NLHxizS5atX6ajIM8LIPeg4ixQwxA4gg0mHhCowKtQUc3QoPfuCHihFNqXT');
define('NONCE_KEY',        'MdBx0YqAPJSFgGWJea4ezsQwAtQiXvPADKnXaSPjfoA8uTVQcyJ1C2gu2fDxyDBN');
define('AUTH_SALT',        '3fNcJLidmhHAWXVEwd4nrc42U5HpSV21iuJDr78pRzAFixRXRH0Nqeyg11JQvuaq');
define('SECURE_AUTH_SALT', 'U49iXCsBYr5HKTTMaWGfTcem3iaAHWsF1JLF9RAbEBEp08NhIjdTuriUh3PhV7QB');
define('LOGGED_IN_SALT',   'iiw9a9b2Y2GEvXxm2zmNbIQqDmiuxrGIjL52rNNPi7jtvoTuQIoKL4WhAtwdWn3B');
define('NONCE_SALT',       'UFf23YISSxG97b9JyNQYhAiG0m8HLsPLpX9M5Bu0mUvBKYdV6VvLgmpeHmMjfccX');
