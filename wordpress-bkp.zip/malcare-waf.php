<?php
// Please validate auto_prepend_file setting before removing this file

if (file_exists('/home/641609.cloudwaysapps.com/nmrmurtumc/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php')) {
	define("MCDATAPATH", '/home/641609.cloudwaysapps.com/nmrmurtumc/public_html/wp-content/mc_data/');
	define("MCCONFKEY", 'aca4a4ec6434f65ed3f173543392d7de');
	include_once('/home/641609.cloudwaysapps.com/nmrmurtumc/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php');
}
?>
